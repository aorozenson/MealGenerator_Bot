import sqlite3 as sq

db = sq.connect(r'tg.db')
cur = db.cursor()

async def db_start():
    cur.execute ("CREATE TABLE IF NOT EXISTS users("
                 "user_name TEXT PRIMARY KEY, "
                 "date DATE)")
    db.commit()

async def cmd_start_db(user, activity_date):
    existing_user = cur.execute("SELECT * FROM users WHERE user_name = ?", (user,)).fetchone()
    
    if not existing_user:
        cur.execute("INSERT INTO users (user_name, date) VALUES (?, ?)", (user, activity_date))
        print('добавлен')
    else:
        cur.execute("UPDATE users SET date = ? WHERE user_name = ?", (activity_date, user))
        print('обновлен')
    
    db.commit()

async def cmd_admin():
    cur.execute("SELECT COUNT(*) FROM users")
    result = cur.fetchone()
    
    if result:
        length = result[0]
        print(length)
        return f"Найдено пользователей: {length}"
    else:
        return "Данные не найдены."
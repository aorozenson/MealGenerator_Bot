from aiogram import Bot, executor, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup
import pandas as pd
import db
import config

bot = Bot(token=config.token)

dp = Dispatcher(bot = bot)

main = ReplyKeyboardMarkup(resize_keyboard=True)
main.add('Завтрак').add('Обед').add('Ужин')

dishes = pd.read_csv('dishes.csv')
    
async def breakfast():
    breakfast = pd.concat([dishes[dishes['Category'] == 'Утро в «Кофемании»'].sample(), dishes[dishes['Category'] == 'Кофе'].sample()])
    text = f"*Утро в «Кофемании:* {breakfast.iat[0, 0]} \n\n*Кофе:* {breakfast.iat[1, 0]} \n\n*Цена:* {breakfast['Price'].astype(int).sum()}"
    return text
async def lunch():
    lunch = pd.concat([dishes[dishes['Category'] == 'Супы'].sample(), dishes[dishes['Category'] == 'Горячие блюда'].sample(), dishes[dishes['Category'] == 'Лимонады и смузи'].sample()])
    text = f"*Супы* {lunch.iat[0, 0]} \n\n*Горячие блюда:* {lunch.iat[1, 0]} \n\n*Лимонады и смузи:* {lunch.iat[2, 0]} \n\n*Цена:* {lunch['Price'].astype(int).sum()}"
    return text
async def dinner():
    dinner = pd.concat([dishes[dishes['Category'] == 'Закуски и салаты'].sample(), dishes[dishes['Category'] == 'Паста '].sample(), dishes[dishes['Category'] == 'Лимонады и смузи'].sample()])
    text = f"*Закуски и салаты:* {dinner.iat[0, 0]} \n\n*Паста:* {dinner.iat[1, 0]} \n\n*Селекционные чаи:* {dinner.iat[2, 0]} \n\n*Цена:* {dinner['Price'].astype(int).sum()}"
    return text

async def on_startup(_):
    await db.db_start()
    print('Бот запущен')

@dp.message_handler(commands= ['start'] )
async def send_mes(msg: types.Message) -> None:
    print(msg)
    await msg.answer('Здравствуйте! Какое меню вы хотели бы сгенерировать?', reply_markup=main)
    await db.cmd_start_db(msg.from_user.username, msg.date)

@dp.message_handler(commands= ['admin'] )
async def send_mes(msg: types.Message) -> None:
    print(msg)
    length = await db.cmd_admin()
    await msg.answer(length, reply_markup=main)
    await db.cmd_start_db(msg.from_user.username, msg.date)

@dp.message_handler(text = 'Завтрак')
async def txtmes(msg: types.Message) -> None:
    print (msg)
    answer = await breakfast()
    await msg.answer(answer, reply_markup=main, parse_mode="Markdown")
    await db.cmd_start_db(msg.from_user.username, msg.date)
@dp.message_handler(text = 'Обед')
async def txtmes(msg: types.Message) -> None:
    print (msg)
    answer = await lunch()
    await msg.answer(answer, reply_markup=main, parse_mode="Markdown")
    await db.cmd_start_db(msg.from_user.username, msg.date)
@dp.message_handler(text = 'Ужин')
async def txtmes(msg: types.Message) -> None:
    print (msg)
    answer = await dinner()
    await msg.answer(answer, reply_markup=main, parse_mode="Markdown")
    await db.cmd_start_db(msg.from_user.username, msg.date)

@dp.message_handler()
async def txtmes(msg: types.Message) -> None:
    print (msg)
    await msg.answer('Команда не распознана', reply_markup=main)
    await db.cmd_start_db(msg.from_user.username, msg.date)


if __name__ == "__main__":
    executor.start_polling(dp, on_startup=on_startup)
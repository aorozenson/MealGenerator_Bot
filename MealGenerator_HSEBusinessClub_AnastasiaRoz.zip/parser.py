from selenium import webdriver as wd
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pandas as pd

br = wd.Chrome()
br.get('https://coffeemania.ru')

products = br.find_elements(By.CSS_SELECTOR, 'a.gaProductClick')

names = []
categories = []
prices = []

for element in products: 
    name = element.get_attribute('data-title')
    category = element.get_attribute('data-category')
    price = element.get_attribute('data-price')
    
    if name != '' and category != '' and price != '':
        names.append(name)
        categories.append(category)
        prices.append(price)

df = pd.DataFrame(list(zip(names, categories, prices)), columns =['Name', 'Category', 'Price'])
df = df.drop_duplicates()
df.reset_index(drop = True, inplace=True)

df.to_csv('dishes.csv', index = False)
